This repository contains a matlab implementation of the Delta Robot kinematics:
* inverse kinematics
* forward kinematics
* workspace plot
